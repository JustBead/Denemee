plans = {
    "günlük": {"price_tl": 40, "price_usd": 2},
    "haftalık": {"price_tl": 80, "price_usd": 4},
    "aylık": {"price_tl": 200, "price_usd": 10}
}
